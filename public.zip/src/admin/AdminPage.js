// AdminPage.js
import React, { useState } from 'react';
import { Navigate } from 'react-router-dom'; // Import Navigate component for redirection
import './AdminPage.css'; // Import CSS file for styling

const AdminPage = () => {
  const [personalInfo, setPersonalInfo] = useState(localStorage.getItem('personalInfo') || '');
  const [education, setEducation] = useState(localStorage.getItem('education') || '');
  const [workExperience, setWorkExperience] = useState(localStorage.getItem('workExperience') || '');
  const [skills, setSkills] = useState(localStorage.getItem('skills') || '');
  const [isDataSaved, setIsDataSaved] = useState(false); // Track whether data is saved

  const handleSave = () => {
    // Save modified data to local storage
    localStorage.setItem('personalInfo', personalInfo);
    localStorage.setItem('education', education);
    localStorage.setItem('workExperience', workExperience);
    localStorage.setItem('skills', skills);
    alert('Data saved successfully!');
    // Set isDataSaved to true to trigger redirection
    setIsDataSaved(true);
  };

  // Redirect to the CV page if data is saved
  if (isDataSaved) {
    return <Navigate to="/cv" />;
  }

  return (
    <div className="admin-container">
      <h2>CV Editing</h2>
      <div className="cv-section">
        <label>Personal Information:</label>
        <textarea value={personalInfo} onChange={(e) => setPersonalInfo(e.target.value)} />
      </div>
      <div className="cv-section">
        <label>Education:</label>
        <textarea value={education} onChange={(e) => setEducation(e.target.value)} />
      </div>
      <div className="cv-section">
        <label>Work Experience:</label>
        <textarea value={workExperience} onChange={(e) => setWorkExperience(e.target.value)} />
      </div>
      <div className="cv-section">
        <label>Skills:</label>
        <textarea value={skills} onChange={(e) => setSkills(e.target.value)} />
      </div>
      <button className="save-button" onClick={handleSave}>Save</button>
    </div>
  );
};

export default AdminPage;
