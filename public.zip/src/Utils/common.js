export const setLogIn = () =>{
    localStorage.setItem("isLoggedIn", true);
} 

export const getLogIn = () =>{
    const loginCheck=localStorage.getItem("isLoggedIn");
    return loginCheck
    
} 

export const setlogOut =()=>{
    localStorage.setItem("isLoggedIn",false)
}

export const getlogOut =()=>{
    const loginCheck = localStorage.setItem("isLoggedIn")
  return  loginCheck
}