// LoginPage.js
import React, { useEffect, useState } from 'react';
import { Navigate, useNavigate } from 'react-router-dom';
import { useAuth } from '../auth';
import { getLogIn } from '../Utils/common';

const LoginPage = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const { login } = useAuth();
  const navigate = useNavigate();
  const [loginChecker,setLoginChecker] = useState('false')
  
  // console.log(isLoggedIn)
  useEffect(()=>{
    // const isLoggedIn = getLogIn();
    setLoginChecker(getLogIn())
  },[loginChecker])
  const handleLogin = () => {
    // debugger
    const isLoggedIn = getLogIn();
    login(username, password);
    console.log(loginChecker)
    if (loginChecker=='true') {
      navigate('/admin');
    } if(loginChecker=='false') {
      setError('Incorrect username or password');
    }
  };


  return (
    <div>
      <h2>Login</h2>
      <input type="text" placeholder="Username" value={username} onChange={(e) => setUsername(e.target.value)} />
      <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />
      <button onClick={handleLogin}>Login</button>
      {error && <p>{error}</p>}
    </div>
  );
};

export default LoginPage;
